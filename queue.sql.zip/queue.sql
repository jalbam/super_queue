-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- Servidor: localhost
-- Temps de generació: 05-11-2014 a les 01:42:34
-- Versió del servidor: 5.0.51
-- PHP versió: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Base de dades: `my_wechat_queue`
-- 

-- --------------------------------------------------------

-- 
-- Estructura de la taula `couples`
-- 

CREATE TABLE `couples` (
  `user1_id` int(10) unsigned NOT NULL,
  `user2_id` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`user1_id`,`user2_id`),
  UNIQUE KEY `user2_id` (`user2_id`),
  UNIQUE KEY `user1_id` (`user1_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Bolcant dades de la taula `couples`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de la taula `finalists`
-- 

CREATE TABLE `finalists` (
  `user_id` int(10) unsigned NOT NULL,
  `lottery_result` enum('1','2','3','4','5','6','7','8','9','10','11','12') default NULL,
  `time` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Bolcant dades de la taula `finalists`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de la taula `invitations`
-- 

CREATE TABLE `invitations` (
  `guest_user_id` int(10) unsigned NOT NULL,
  `host_user_id` int(10) unsigned NOT NULL,
  `time` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`guest_user_id`),
  UNIQUE KEY `host_guest` (`guest_user_id`,`host_user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Bolcant dades de la taula `invitations`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de la taula `queues`
-- 

CREATE TABLE `queues` (
  `user_id` int(10) unsigned NOT NULL,
  `world` int(10) unsigned NOT NULL,
  `initial_position` int(10) unsigned NOT NULL auto_increment,
  PRIMARY KEY  (`user_id`),
  UNIQUE KEY `initial_position` (`initial_position`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Bolcant dades de la taula `queues`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de la taula `users`
-- 

CREATE TABLE `users` (
  `user_id` int(10) unsigned NOT NULL auto_increment,
  `user_name` varchar(150) NOT NULL,
  `user_password` varchar(150) NOT NULL,
  `user_gender` enum('male','female') NOT NULL,
  `user_keyword` varchar(333) default NULL,
  PRIMARY KEY  (`user_id`),
  UNIQUE KEY `name_password` (`user_name`,`user_password`),
  UNIQUE KEY `user_keyword` (`user_keyword`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Bolcant dades de la taula `users`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de la taula `winners_or_losers`
-- 

CREATE TABLE `winners_or_losers` (
  `user_id` int(10) unsigned NOT NULL,
  `prize_type` enum('prize_1','prize_2','prize_3','prize_4','prize_5','prize_6') default NULL,
  `time` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `winner` tinyint(1) NOT NULL default '1',
  `prize_given` tinyint(1) NOT NULL default '0',
  `shop_selected` varchar(50) default NULL,
  PRIMARY KEY  (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Bolcant dades de la taula `winners_or_losers`
-- 

